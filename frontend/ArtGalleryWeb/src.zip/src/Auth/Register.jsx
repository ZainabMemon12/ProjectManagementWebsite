import React from 'react'



const Register = () => {
  return (
<>
<div className="reg-con">
    <form action="">
        
    </form>
</div>
</>
  )
}

export default Register