import React from "react";
import "./App.css";
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import Register from "./Auth/Register";
import Login from "./Auth/Login";
import MainPage from "./pages/MainPage";
import AdminDashboard from "./pages/AdminDashboard";
import UserDashboard from "./pages/UserDashboard";
import { useAuth } from "./contexts/AuthContext";

const App = () => {
  const { isAuthenticated, userData } = useAuth(); 

  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/login"
          element={!isAuthenticated ? <Login /> : <Navigate to="/admin-dashboard" />}
        />
        
        <Route
          path="/dashboard"
          element={
            isAuthenticated ? (
              userData.role === "admin" ? (
                <Navigate to="/admin-dashboard" />
              ) : (
                <Navigate to="/user-dashboard" />
              )
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        
        <Route path="/admin-dashboard" element={isAuthenticated && userData.role === "admin" ? <AdminDashboard /> : <Navigate to="/login" />} />

        <Route path="/user-dashboard" element={isAuthenticated && userData.role === "user" ? <UserDashboard /> : <Navigate to="/login" />} />
      </Routes>
    </Router>
  );
};

export default App;