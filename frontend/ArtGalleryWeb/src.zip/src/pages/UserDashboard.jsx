import React from 'react'
import {useAuth} from '../contexts/AuthContext.jsx';
import { Button } from 'antd';

const UserDashboard = () => {
    const {userData,logout}= useAuth()
    
    const handleLogout = async()=>{
      await logout()
    }
  return (
    <>
 <div>UserDashboard</div>
 <Button onClick={handleLogout}>logout</Button>

    </>
   
  )
}

export default UserDashboard