import React from 'react';
import {useAuth} from '../contexts/AuthContext.jsx';
import { Button } from 'antd';


const AdminDashboard = () => {
    const {userData,logout}= useAuth()
    const handleLogout = async()=>{
      await logout()
    }
  return (
    <>
 <div>AdminDashboard</div>
 <Button onClick={handleLogout}>logout</Button>

    </>
   
  )
}

export default AdminDashboard;